﻿To ensure that only authenticated users can access the Web API, all endpoints are protected using [OpenID Connect](https://openid.net/connect/) authentication.

To retrieve an OpenID token, see [how to request the OpenID token](https://dhi-developer-documentation.azurewebsites.net/domain_services/web-api-mikecloud-authentication/#requesting-the-openid-token).

